#include <QCoreApplication>

#include <iostream>
#include "test.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    return a.exec();
}

