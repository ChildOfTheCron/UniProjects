#include <QtGui>


#if defined TEST
 #define TEST_COMMON_DLLSPEC Q_DECL_EXPORT
#else
 #define TEST_COMMON_DLLSPEC Q_DECL_IMPORT
#endif

namespace MathLibrary
{
    // This class is exported from the MathLibrary.dll
    class Functions
    {
    public:
        // Returns a + b
        static TEST_COMMON_DLLSPEC double Add(double a, double b);

        // Returns a * b
        static TEST_COMMON_DLLSPEC double Multiply(double a, double b);

        // Returns a + (a * b)
        static TEST_COMMON_DLLSPEC double AddMultiply(double a, double b);
    };
}
